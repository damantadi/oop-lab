#include<iostream>
using namespace std;

class complex{
private:
  int real;
  int img;
public:
  void getData(){
    cout<<"Enter real part:\n";
    cin>>real;
    cout<<"Enter imaginary part:\n";
    cin>>img;
    printData();
  }
  void printData(){
    cout<<"Complex number is "<<real<<" + "<<img<<"i"<<endl;
  }
};
int main(){
  complex com[5];
  int n=5;
  for(int i=0;i<n;i++){
    cout<<"Enter details of "<<i+1<<" complex number:\n";
    com[i].getData();
  }
}